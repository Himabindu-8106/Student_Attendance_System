from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import date

app = Flask(__name__)
app.secret_key = "change-this-secret-key"

DB_NAME = "attendance.db"

def connect_db():
    con = sqlite3.connect(DB_NAME)
    con.row_factory = sqlite3.Row
    return con

def create_tables():
    with connect_db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                roll TEXT NOT NULL UNIQUE,
                course TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                att_date TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('Present', 'Absent')),
                UNIQUE(student_id, att_date),
                FOREIGN KEY(student_id) REFERENCES students(id)
            )
        """)

@app.route("/")
def index():
    today = date.today().isoformat()
    with connect_db() as con:
        total = con.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        present = con.execute(
            "SELECT COUNT(*) FROM attendance WHERE att_date=? AND status='Present'",
            (today,)
        ).fetchone()[0]
        absent = con.execute(
            "SELECT COUNT(*) FROM attendance WHERE att_date=? AND status='Absent'",
            (today,)
        ).fetchone()[0]
    return render_template("index.html", total=total, present=present,
                           absent=absent, today=today)

@app.route("/add", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        roll = request.form.get("roll", "").strip()
        course = request.form.get("course", "").strip()

        if not name or not roll or not course:
            flash("Please fill in all fields.")
            return redirect(url_for("add_student"))

        try:
            with connect_db() as con:
                con.execute(
                    "INSERT INTO students (name, roll, course) VALUES (?, ?, ?)",
                    (name, roll, course)
                )
            flash("Student added successfully.")
            return redirect(url_for("students"))
        except sqlite3.IntegrityError:
            flash("That roll number already exists. Please use a different one.")

    return render_template("add_student.html")

@app.route("/students")
def students():
    with connect_db() as con:
        rows = con.execute(
            "SELECT id, name, roll, course FROM students ORDER BY roll"
        ).fetchall()
    return render_template("students.html", students=rows)

@app.route("/attendance", methods=["GET", "POST"])
def attendance():
    selected_date = request.values.get("att_date", date.today().isoformat())

    # Basic date format validation
    try:
        date.fromisoformat(selected_date)
    except ValueError:
        selected_date = date.today().isoformat()

    with connect_db() as con:
        students_list = con.execute(
            "SELECT id, name, roll, course FROM students ORDER BY roll"
        ).fetchall()

        if request.method == "POST":
            for student in students_list:
                status = request.form.get(str(student["id"]))
                if status in ("Present", "Absent"):
                    con.execute("""
                        INSERT INTO attendance (student_id, att_date, status)
                        VALUES (?, ?, ?)
                        ON CONFLICT(student_id, att_date)
                        DO UPDATE SET status=excluded.status
                    """, (student["id"], selected_date, status))
            flash("Attendance saved for " + selected_date + ".")
            return redirect(url_for("attendance", att_date=selected_date))

        saved_rows = con.execute(
            "SELECT student_id, status FROM attendance WHERE att_date=?",
            (selected_date,)
        ).fetchall()
        saved = {row["student_id"]: row["status"] for row in saved_rows}

    return render_template("attendance.html", students=students_list,
                           records=saved, selected_date=selected_date)

@app.route("/report")
def report():
    with connect_db() as con:
        rows = con.execute("""
            SELECT s.name, s.roll,
                   COUNT(a.id) AS total_days,
                   COALESCE(SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END), 0) AS present_days,
                   COALESCE(SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END), 0) AS absent_days
            FROM students s
            LEFT JOIN attendance a ON s.id = a.student_id
            GROUP BY s.id
            ORDER BY s.roll
        """).fetchall()
    return render_template("report.html", records=rows)

if __name__ == "__main__":
    create_tables()
    app.run(debug=True)
